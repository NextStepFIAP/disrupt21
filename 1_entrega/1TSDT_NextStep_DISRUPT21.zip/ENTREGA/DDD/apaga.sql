DROP TABLE t_nxt_evento CASCADE CONSTRAINTS ;

DROP TABLE t_nxt_personagem CASCADE CONSTRAINTS ;

DROP TABLE t_nxt_personagem_evento CASCADE CONSTRAINTS ;

DROP SEQUENCE sq_nxt_evento;

DROP SEQUENCE sq_nxt_personagem;

DROP SEQUENCE sq_nxt_personagem_evento;



